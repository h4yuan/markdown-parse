[i like cats]
meow meow meow
(also known as felis catus)
