[a link!](https://somethin)g.com)
[anot\]her link!](so]me-pa]ge.h{tml)
